
$name = "Nicolas"
Welcome <?php '$name' ?>